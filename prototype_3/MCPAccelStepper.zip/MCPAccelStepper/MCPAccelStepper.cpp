#include "MCPAccelStepper.h"

MCPAccelStepper::MCPAccelStepper(
    Adafruit_MCP23X17* mcp,
    uint8_t p1, uint8_t p2,
    uint8_t p3, uint8_t p4)
    : AccelStepper(AccelStepper::FULL4WIRE)
{
  _mcp = mcp;
  _pins[0] = p1;
  _pins[1] = p2;
  _pins[2] = p3;
  _pins[3] = p4;

  for (int i = 0; i < 4; i++) {
    _mcp->pinMode(_pins[i], OUTPUT);
    _mcp->digitalWrite(_pins[i], LOW);
  }
}

void MCPAccelStepper::step(long stepDirection)
{
  // stepDirection = +1 (forward) or -1 (backward)

  _seqIndex += (stepDirection > 0) ? 1 : -1;

  if (_seqIndex > 3) _seqIndex = 0;
  if (_seqIndex < 0) _seqIndex = 3;

  uint8_t pattern = FULLSTEP_SEQ[_seqIndex];

  for (int i = 0; i < 4; i++) {
    uint8_t level = (pattern >> i) & 1;
    _mcp->digitalWrite(_pins[i], level);
  }
}
