#pragma once
#include <Arduino.h>
#include <AccelStepper.h>
#include <Adafruit_MCP23X17.h>

static const uint8_t FULLSTEP_SEQ[4] = {
  0b0001,
  0b0010,
  0b0100,
  0b1000
};

class MCPAccelStepper : public AccelStepper {
public:
  MCPAccelStepper(Adafruit_MCP23X17* mcp,
                  uint8_t p1, uint8_t p2,
                  uint8_t p3, uint8_t p4);

protected:
  void step(long step) override;

private:
  Adafruit_MCP23X17* _mcp;
  uint8_t _pins[4];
  int8_t _seqIndex = 0;   // tracks 0–3 for full-step
};
